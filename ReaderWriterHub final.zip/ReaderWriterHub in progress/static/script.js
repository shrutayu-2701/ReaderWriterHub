document.addEventListener("DOMContentLoaded", () => {
    const toggle = document.getElementById("darkModeToggle");

    // Load saved mode
    const saved = localStorage.getItem("darkMode");
    if (saved === "true") {
        document.body.classList.add("dark-mode");
        toggle.textContent = "🌞";
    }

    toggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        const isDark = document.body.classList.contains("dark-mode");
        localStorage.setItem("darkMode", isDark);
        toggle.textContent = isDark ? "🌞" : "🌙";
    });

    // Optional scroll-to-top button logic (add button in HTML if desired)
    const scrollBtn = document.getElementById("scrollToTopBtn");
    if (scrollBtn) {
        window.onscroll = () => {
            scrollBtn.style.display = (window.scrollY > 100) ? "block" : "none";
        };
        scrollBtn.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });
    }

    // Optional form input validation styling
    const forms = document.querySelectorAll("form");
    forms.forEach((form) => {
        form.addEventListener("submit", (e) => {
            const inputs = form.querySelectorAll("input, textarea");
            inputs.forEach((input) => {
                if (!input.checkValidity()) {
                    input.classList.add("input-error");
                } else {
                    input.classList.remove("input-error");
                }
            });
        });
    });
});

from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
from config import Config
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import timedelta

app = Flask(__name__)
app.config.from_object(Config)
mysql = MySQL(app)

# Session Timeout (e.g., 15 minutes)
app.permanent_session_lifetime = timedelta(minutes=15)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')
        role = request.form['role']
        
        # Ensure valid inputs
        if not username or len(password) < 8:
            flash('Invalid input. Please ensure username and password are valid.', 'danger')
            return redirect(url_for('register'))
        
        # Insert user into database
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO users (username, password, role) VALUES (%s, %s, %s)", (username, password, role))
            mysql.connection.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('register'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password_input = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, password, role FROM users WHERE username=%s", (username,))
        user = cur.fetchone()

        if user and check_password_hash(user[1], password_input):
            session.permanent = True  # To enable session timeout
            session['user_id'] = user[0]
            session['role'] = user[2]
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials, please try again.', 'danger')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('You need to log in first.', 'warning')
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    cur.execute("SELECT works.id, title, content, username FROM works JOIN users ON users.id = works.user_id")
    works = cur.fetchall()
    return render_template('dashboard.html', works=works, role=session['role'])

@app.route('/publish', methods=['GET', 'POST'])
def publish():
    if 'user_id' not in session or session['role'] != 'writer':
        flash('You need to be a writer to publish works.', 'warning')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        
        if not title or len(content) < 10:
            flash('Please provide a valid title and content.', 'danger')
            return redirect(url_for('publish'))
        
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO works (title, content, user_id) VALUES (%s, %s, %s)", (title, content, session['user_id']))
            mysql.connection.commit()
            flash('Your work has been published!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('publish'))

    return render_template('publish.html')

@app.route('/work/<int:work_id>', methods=['GET', 'POST'])
def work_detail(work_id):
    cur = mysql.connection.cursor()

    if request.method == 'POST' and 'user_id' in session:
        comment = request.form['comment']
        
        if len(comment) < 5:
            flash('Comment must be at least 5 characters long.', 'danger')
            return redirect(url_for('work_detail', work_id=work_id))

        try:
            cur.execute("INSERT INTO comments (content, work_id, user_id) VALUES (%s, %s, %s)", (comment, work_id, session['user_id']))
            mysql.connection.commit()
            flash('Comment posted successfully!', 'success')
        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error: {str(e)}', 'danger')

    cur.execute("SELECT title, content, username FROM works JOIN users ON users.id = works.user_id WHERE works.id = %s", [work_id])
    work = cur.fetchone()

    cur.execute("SELECT comments.content, users.username FROM comments JOIN users ON users.id = comments.user_id WHERE comments.work_id = %s", [work_id])
    comments = cur.fetchall()
    
    return render_template('work_detail.html', work=work, comments=comments)

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

class Config:
    SECRET_KEY = 'kabir'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'kabir230728'
    MYSQL_DB = 'reader_writer_hub'